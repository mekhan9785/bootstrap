
jQuery(document).ready(function($) {
	$('.my-carousel').owlCarousel({
		loop:true,
		dots:false,
		nav:true,
		//mouseDrag:true,
		//lazyLoad:true,
		autoplay:false,
		//autoplayTimeout:4000,
		//autoplayHoverPause:true,
		animateOut: 'slideOutDown',
  //  animateIn: 'flipInX',
		responsive:{
				0:{
					items:1
				},
				600:{
					items:1
				},
				1000:{
					items:1
				}
			}
	});


$('.testimonial-carousel').owlCarousel({
	loop:true,
	margin:20,
	dots:false,
	nav:true,
	mouseDrag:false,
	autoplay:false,
	//items: 5
	responsive:{
		0:{
			items:1
		},
		600:{
			items:1
		},
		800:{
			items:1
		},
		1000:{
			items:2
		}
	}
});
	
$('.team-carousel').owlCarousel({
	loop:true,
	margin:20,
	dots:false,
	nav:true,
	mouseDrag:false,
	autoplay:false,
	//items: 5
	responsive:{
		0:{
			items:1
		},
		600:{
			items:1
		},
		800:{
			items:1
		},
		1000:{
			items:4
		}
	}
});

	new WOW().init();
	$('.counter').each(function () {
	$(this).prop('Counter',0).animate({
		Counter: $(this).text()
	}, {
		duration: 5000,
		easing: 'swing',
		step: function (now) {
			$(this).text(Math.ceil(now));
		}
	});
});

// Portfolio
jQuery(document).ready(function($) {
	$('a[data-rel^=lightcase]').lightcase();


// init Isotope
var $grid = $('.grid').isotope({
	itemSelector: '.grid-item',
	layoutMode: 'masonry'
});

//Change filter-active class on a
jQuery(function() {
jQuery( '.filter-button-group' ).on( 'click', 'a', function() {
	var filterValue = $(this).attr('data-filter');
	$grid.isotope({ filter: filterValue });
	jQuery( this ).parent().find( 'a.filter-active' ).removeClass( 'filter-active' );
	jQuery( this ).addClass( 'filter-active' );
});
});

var btn = $('#shn-button');

$(window).scroll(function() {
	if ($(window).scrollTop() > 300) {
		btn.addClass('show');
	} else {
		btn.removeClass('show');
	}
});

btn.on('click', function(e) {
	e.preventDefault();
	$('html, body').animate({scrollTop:0}, '300');
});


$('li').click(function() {
	  $(this).addClass('active').siblings().removeClass('active');
});
});
});
